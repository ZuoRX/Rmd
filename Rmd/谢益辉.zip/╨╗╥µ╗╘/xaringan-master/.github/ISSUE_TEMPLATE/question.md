---
name: Question
about: Got a question about this package? This may not be the best place to ask it.
---

Please consider [asking a question on Stack Overflow](https://yihui.name/en/2017/08/so-gh-email/) (with at least tags `r` and [`xaringan`](https://stackoverflow.com/tags/xaringan)) or in [RStudio Community](https://community.rstudio.com) to let more people help you. We are more committed to fixing bugs than answering general questions here on Github due to limited human resources. Thanks for your understanding!
