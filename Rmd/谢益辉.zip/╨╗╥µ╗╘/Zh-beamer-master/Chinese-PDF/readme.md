# 说明

在 `default.latex` 的11行加入了 `xecjk` 就能使用中文了。
